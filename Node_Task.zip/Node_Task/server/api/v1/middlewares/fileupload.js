let multer = require("multer");
let fileFilterConfig = require("../config/fileFilter.config");
let filterSet = fileFilterConfig.fileFilter.filter;
let filterExt = fileFilterConfig.fileFilter.filterExt;

let path = require("path");
let APP_CONFIG = require("../config/app.config");
let fileSize = 350; // default size kb. ex: 150 = 150 kb
let fileDest = 'public/'; // default path

/**
* @author SathishKumar S <v2e12612>
* @abstract file upload using multer
* @version 1.0.0
* @param1 parameter arg name and no of files | array type
*/
let fileFilters = (req, file, cb) => {

  let file_path = req.originalUrl;
  let extensions_validate;

  for (let index = 0; index < filterSet.length; index++) {
    if (filterSet[index][0] == file_path) {
      fileSize = filterSet[index][2];
      fileDest = filterSet[index][3];
      if (filterSet[index][0] == "/api/v1/user/profile-update") {
        
        if (req.body.filetypeGST == "GST" && req.files.length == 1) {
          fileDest = filterSet[index][4];
        }
        if (req.body.filetypeKYC == "KYC" && req.files.length == 1) {
          fileDest = filterSet[index][3];
        }
        if (req.files.length == 2) {
          fileDest = filterSet[index][4];
        }

      }
      let filters = filterSet[index][1].split("|");

      for (let key = 0; key < filters.length; key++) {
        let filter = filters[key];
        if (extensions_validate == null) {
          extensions_validate = filterExt[filter];
        } else {
          extensions_validate = extensions_validate.concat(
            "," + filterExt[filter]
          );
        }
      }
    }
  }

  let arr_extensions = extensions_validate.split(",");
  if (arr_extensions == null) {
    return cb(new Error("File not found"));
  }

  if (
    arr_extensions.indexOf(
      file.originalname.split(".")[file.originalname.split(".").length - 1]
    ) === -1
  ) {
    return cb(new Error("Wrong extension. Not accepted"));
  }
  cb(null, true);
};

let multersave = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, fileDest);
  },
  filename: function (req, file, cb) {

    APP_CONFIG.config.Org_FileExt = path.extname(file.originalname);
    let string = file.originalname.split(".");
   
    if (req.body.filetypeGST == "GST" && req.files.length == 1) {
      APP_CONFIG.config.Org_GCTFileName = string[0];
    }
    if (req.body.filetypeKYC == "KYC" && req.files.length == 1) {
      APP_CONFIG.config.Org_FileName = string[0];
    }
    if (req.files.length == 2) {
      APP_CONFIG.config.Org_GCTFileName = string[0];
    }
    if (req.files.length == 1) {
      APP_CONFIG.config.Org_FileName = string[0];
    }
    cb(null, string[0] + path.extname(file.originalname));

  },
});

export default multer({
  storage: multersave,
  fileFilter: fileFilters,
  // limits: {
  //   fileSize: 1024 * fileSize
  // },
  onError: (err, next) => {
    console.log("Error from multer : " + err);
    next(err);
  }
});









