import * as express from "express";
import masterController from "./masterController";
import middleware from "../../middlewares/auth";

export default express
.Router()

   .get("/city/list", masterController.cityList)
 
   .get("/get-state", masterController.stateList)
  


