import BaseController from "../base.controller";
import masterService from "../../services/master.service";



class MasterController extends BaseController {


  async cityList(req, res) {
    let result;
    try {
      let whereStatement = { is_deleted: 0 };

      if (req.query.state_id) {
        whereStatement.state_id = req.query.state_id;
      }
      let data = await masterService.getCityList(whereStatement);
      if (data.length != 0) {
        result = super.response(
          200,
          data,
          "Successfully retrieved list"
        );
      } else {
        result = super.response(400, "", "No records found");
      }
      super.respond(req, res, result);

    } catch (ex) {
    
      let errResult = super.response(500, ex.message, "Internal Server Error");
      super.respond(req, res, errResult);
    }
  }

  async stateList(req, res) {
    let result;
    let whereStatement;
    try {
      if (req.query.id) {
        whereStatement = { id: req.query.id, is_deleted: 0 };
      }
      else {
        whereStatement = { is_deleted: 0 };
      }


      let data = await masterService.getStateList(whereStatement);
      if (data.length != 0) {
        result = super.response(
          200,
          data,
          "Successfully retrieved list"
        );
      } else {
        result = super.response(400, "", "No records found");
      }
      super.respond(req, res, result);

    } catch (ex) {
     
      let errResult = super.response(500, ex.message, "Internal Server Error");
      super.respond(req, res, errResult);
    }
  }

}
export default new MasterController();
