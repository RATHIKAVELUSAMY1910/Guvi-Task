import * as express from "express";
import UsersController from "./userController";
import middleware from "../../middlewares/auth";
import fileUploadMiddleware from "../../middlewares/fileupload";

export default express

  .Router()

  .post("/", UsersController.saveUserdetails)
  .get("/profile-list",  UsersController.getProfileList)
