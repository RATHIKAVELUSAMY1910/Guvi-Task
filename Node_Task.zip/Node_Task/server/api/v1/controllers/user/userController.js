import BaseController from "../base.controller";
import UserService from "../../services/user.service";

import generalHelper from "../../helpers/general.helper";
import validator from "../../helpers/validation.helper";


class UserController extends BaseController {

  async getProfileList(req, res) {
    let result;

    try {
      let whereStatement = { is_active: 1, is_deleted: 0, id: req.query.id };


      let data = await UserService.Getuserdata(whereStatement);
      if (data.length != 0) {
        result = super.response(200, data, "Successfully retrieved list");

      } else {
        result = super.response(400, "", "No records found");
      }
      super.respond(req, res, result);

    } catch (ex) {

      let errResult = super.response(500, ex.message, "Internal Server Error");
      super.respond(req, res, errResult);
    }
  }

  async saveUserdetails(req, res) {
    let result;
    let query;
    let cond;
    let validate;
    let user_list;
    let exist_mobileno;
    let rules;
    let data;
    let encrypt_pin;
    let role_query;
    try {
      rules = {
        first_name: "required",
        last_name: "required",


      };
      validate = await validator.validate(rules, req.body);
      if (validate.status == 200) {
       
          encrypt_pin = await generalHelper.encryptPassword(req.body.pin_number);
        
        query = {
          first_name: req.body.first_name,
          last_name: req.body.last_name,
          state_id: req.body.state_id,
          city_id:req.body.city_id,
          pin_code:req.body.pin_code,
          address:req.body.address,
          dob:req.body.dob,
          gender: req.body.gender,
          created_by: 2,
          is_active: 1,
          is_deleted: 0,
          mobile_number:req.body.pin_code,
          pin_number:encrypt_pin
        }

        user_list = await UserService.userDetailsSave(query);

        super.respond(req, res, user_list);
      } else {
        result = super.response(
          validate.status,
          validate.error,
          "please fill required fields"
        );
        super.respond(req, res, result);
      }
    } catch (ex) {


      let errResult = super.response(500, ex.message, "Internal Server Error");
      super.respond(req, res, errResult);
    }
  }


}
export default new UserController();
