import loginService from "../../services/login.service";
import BaseController from "../base.controller";
import generalHelper from "../../helpers/general.helper";
import validator from "../../helpers/validation.helper";



export class loginController extends BaseController {

    /**
       * @author Ashok Kumar S <v2e11677>
       * @abstract login
       * @version 1.0
       */
    async loginUser(req, res) {
        try {
            let result;
            let login_details;
            let rules;
            let validate;
            let condition1;
            let user;
            let encrypt_password;
            let data;
            let login_response;
            rules = {
                mobile_number: "required",
                pin_number: "required"

            };
            validate = await validator.validate(rules, req.body);
            if (validate.status == 200) {
                condition1 = { mobile_number: req.body.mobile_number, is_deleted: 0 }
                user = await loginService.userExist(condition1);
                if (!user || user.length == 0) {
                    result = super.response(
                        405,
                        "User does not exist!",
                        "User does not exist!"
                    );
                } else if (user[0].is_active !== true) {
                    result = super.response(
                        402,
                        "User is inactive!",
                        "User is inactive!"
                    );
                } else {
                    encrypt_password = await generalHelper.comparePassword(user[0].pin_number, req.body.pin_number);
                    if (!(encrypt_password)) {
                        result = super.response(403, "Credentials doesn't match!", "Credentials doesn't match!");
                    }
                    else {
                        data = {
                            user_code: user[0].user_code,
                            mobile_number: user[0].mobile_number
                        };


                        login_details = {
                           
                            user_id: user[0].id,
                            user_code: user[0].user_code,
                            first_name: user[0].first_name,
                            last_name: user[0].last_name,
                            mobile_number: user[0].mobile_number,
                            profile_image_path: user[0].profile_image_path,
                        };



                        login_response = {
                            login_details,
                        };
                        result = super.response(
                            200,
                            login_response,
                            "Login successfully"
                        );

                    }
                }
            } else {
                result = super.response(validate.status, validate.error, "Login Aborted");
            }
            res.status(result.status).json(result);
        } catch (ex) {
              console.log(ex)
            let errResult = super.response(500, ex.message.message, "Internal Server Error");
            super.respond(req, res, errResult);
        }
    }


}
export default new loginController();
