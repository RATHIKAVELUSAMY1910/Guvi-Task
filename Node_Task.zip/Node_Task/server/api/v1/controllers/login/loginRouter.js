import * as express from "express";
import loginController from "./loginController";

export default express
.Router()
.post("/login-user", loginController.loginUser);