import userDetailsModel from "../repositories/userDetails.model";
import cityModel from "../repositories/city.model";

import stateModel from "../repositories/state.model";


class RelationService {
  constructor() {
    this.relate();
  }
  relate() {
   
    cityModel.belongsTo(stateModel, {
      as: "city_state",
      foreignKey: "state_id",
    });
    userDetailsModel.belongsTo(stateModel, {
      as: "user_state",
      foreignKey: "state_id",
    });
    userDetailsModel.belongsTo(cityModel, {
      as: "user_city",
      foreignKey: "city_id",
    });
    

  }


  userDetails() {
    return userDetailsModel;
  }
  city() {
    return cityModel;
  }
  state() {
    return stateModel;
  }
  

}
export default new RelationService();
