import Service from "./service";
import RelationService from "./relation.service";



class UserService extends Service {
  /**
   * @author Renuga Devi S<v2e16344>
   * @abstract verify Email
   * @returns json
   */
  async existMobileNumber(condition) {
    let users = RelationService.userDetails();

    let verify_mobileno;
    verify_mobileno = await users.findAll({
      attributes: ["id", "first_name", "last_name", "mobile_number", "pin_number", "is_active", "user_code"],
      raw: true,
      where: condition
    });

    if (verify_mobileno.length != 0) {
      return this.response(200, verify_mobileno, "");
    }
    else {
      return this.response(400);
    }
  }


  async userDetailsSave(query) {
    let user = RelationService.userDetails();
    let datacreate = await user.create(query);
      return this.response(
        200,
        {
          user_id: datacreate.id,
          first_name: datacreate.first_name,
          last_name: datacreate.last_name,
          mobile_number: datacreate.mobile_number,
          
          IsUserExist: false
        },
        "User details saved successfully"
      );
  }

 
  async Getuserdata(condn) {
    let user = RelationService.userDetails();
    return await user.findOne({
     raw:true,
      where: condn
    });
    
  }
  
  
 

  

 
}
export default new UserService();
