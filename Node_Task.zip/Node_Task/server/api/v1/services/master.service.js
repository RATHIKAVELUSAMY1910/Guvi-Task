import Service from "./service";
import RelationService from "./relation.service";
const sequelize = require("sequelize");
class UserService extends Service {

  
  async getCityList(con) {

    let City = RelationService.city();
    return await City.findAll({
      attributes: ["id", ["city_name", "name"], "state_id", "is_deleted"],
      include: {
        association: "city_state",
        attributes: ["state_name"]
      },
      where: con,
      tableHint: sequelize.TableHints.NOLOCK,
      order: [["city_name", "ASC"]],
    });
  }

  async getStateList(con) {

    let State = RelationService.state();
    return await State.findAll({
      attributes: ["id", ["state_name", "name"], "is_deleted"],
      where: con,
      tableHint: sequelize.TableHints.NOLOCK,
      order: [["state_name", "ASC"]],
    });
  }

 
  

  async getUserList(con) {
    let userDetails = RelationService.userDetails();
    return await userDetails.findAll({
      where: con, order: [
        ['id', 'DESC'],]
    });
  }

  

}
export default new UserService();
