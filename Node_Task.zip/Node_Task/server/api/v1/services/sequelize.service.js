import * as DataTypes from 'sequelize/lib/data-types';
const Sequelize = require("sequelize");
const Settings = require("../config/app.config");

/**
 * @author Renuga <v2316344>
 * @abstract Sequelize class to establish connection with database for all the services
 * @version 1.0.0
 */
class SequelizeService {

  /**
   * @author Renuga <v2316344>
   * @abstract create connection with database
   * @version 1.0.0
   * @returns Connection Object
   */
  connect() {
    const newConnection = new Sequelize(
      Settings.config.DB_NAME,
      Settings.config.DB_USER,
      Settings.config.DB_PASSWORD,
      {
        host: Settings.config.DB_HOST,
        dialect: Settings.config.DIALECT,
        pool: {
          max: 10,
          min: 0,
          idle: 200000,
          acquire: 1000000
        },

      }

    );
    return newConnection;
  }

  /**
   * @author Renuga <v2316344>
   * @abstract create sql connection with database
   * @version 1.0.0
   * @returns Connection Object
   */
  sqlconnect() {
    var config = {
      user: Settings.config.DB_USER,
      password: Settings.config.DB_PASSWORD,
      server: Settings.config.DB_HOST,
      database: Settings.config.DB_NAME,
      options: {
        encrypt: true,
        enableArithAbort: true,
      },
    };
    return config;

  }
  /**
   * @author Renuga <v2316344>
   * @abstract check connection with database
   * @version 1.0.0
   * @returns Object
   */
  checkConnection() {
    let connection = this.connect();
    return connection
      .authenticate()
      .then(() => {
        const result = {
          status: 200,
          message: "Connection has been established successfully."
        };
        return Promise.resolve(result);
      })
      .catch(err => {
        const result = {
          status: 400,
          message: "Unable to connect to the database:" + err
        };
        return Promise.resolve(result);
      })

      .finally(() => {
        connection.close().then(() => {
          console.log("Connection closed");
        });
      });
  }

  /**
   * @author Renuga <v2316344>
   * @abstract close connection with database
   * @version 1.0.0
   */
  close(connection) {
    connection.close();
  }

  /**
   * @author Renuga <v2316344>
   * @abstract sync repositories with database
   * @version 1.0.0
   */
  migrate(connection) {
    connection.sync({ force: true }).then(() => {
      console.log(`Database & tables created!`);
    });
  }

  convertdate() {

    const Sequelize = require('sequelize');

    // Override timezone formatting for MSSQL
    Sequelize.DATE.prototype._stringify = function _stringify(date, options) {
      return this._applyTimezone(date, options).format('YYYY-MM-DD HH:mm:ss.SSS');
      return date;

    };
  }

}

export default new SequelizeService();
