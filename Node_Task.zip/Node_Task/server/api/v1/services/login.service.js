import Service from "./service";
import RelationService from "./relation.service";
class loginService extends Service {

  async userExist(cond) {
    let User = RelationService.userDetails();
    return User.findAll({ where: cond });
  }

  

}
export default new loginService();
