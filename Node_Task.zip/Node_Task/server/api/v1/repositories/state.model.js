import SequelizeService from "../services/sequelize.service";
const Sequelize = require("sequelize");
const Model = Sequelize.Model;
const sequelize = SequelizeService.connect();

export default class state extends Model {}
state.init(
  {    
    id: {     
      type: Sequelize.INTEGER,
      primaryKey: true,     
      allowNull: false,
      autoIncrement:true
    },   
    state_name: {
      type: Sequelize.STRING,
      allowNull: false,
    },   
    is_deleted: {
      type: Sequelize.BOOLEAN,
      allowNull: true,
      defaultValue: 0
    }, 
    created_by: {
      type: Sequelize.STRING,
      allowNull: false
    },
    updated_by: {
      type: Sequelize.STRING,
      allowNull: true
    },         
  },
  {
    sequelize,
    tableName: "state_master"
  }
);
