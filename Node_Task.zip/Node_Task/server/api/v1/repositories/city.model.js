import SequelizeService from "../services/sequelize.service";
const Sequelize = require("sequelize");
const Model = Sequelize.Model;
const sequelize = SequelizeService.connect();

export default class City extends Model {}
City.init(
  {    
    id: {     
      type: Sequelize.INTEGER,
      primaryKey: true,     
      allowNull: false,
      autoIncrement:true
    },
    city_name: {
      type: Sequelize.STRING,
      allowNull: false,
    },  
    state_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      }, 
    is_deleted: {
      type: Sequelize.BOOLEAN,
      allowNull: false
    },     
    created_by: {
      type: Sequelize.STRING,
      allowNull: false
    },
    updated_by: {
      type: Sequelize.STRING,
      allowNull: true
    },      
    updatedAt: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
    },
    createdAt: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
    },
  },
  {
    sequelize,
    tableName: "city_master"
  }
);
