import SequelizeService from "../services/sequelize.service";
const Sequelize = require("sequelize");
const Model = Sequelize.Model;
const sequelize = SequelizeService.connect();

export default class UserDetails extends Model {}
UserDetails.init(
  {    
    id: {     
      type: Sequelize.INTEGER,
      primaryKey: true,     
      allowNull: false,
      autoIncrement:true
    },   
    user_code: {
        type: Sequelize.STRING,
        allowNull: true,
      },
    first_name: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    last_name: {
        type: Sequelize.STRING,
        allowNull: true
    },   
    mobile_number: {
        type: Sequelize.STRING,
        allowNull: true
    },
    pin_number: {
        type: Sequelize.STRING,
        allowNull: true
    },
    city:{
      field:"city_id",
        type: Sequelize.INTEGER,
        allowNull: true   
    },
    state: {
      field:"state_id",
        type: Sequelize.INTEGER,
        allowNull: true
    },
    pin_code: {
        type: Sequelize.STRING,
        allowNull: true
    },
    address: {
      type: Sequelize.STRING,
      allowNull: true
    },
    gender: {
      type: Sequelize.INTEGER,
      allowNull: true
    },
    dob: {
      type: Sequelize.STRING,
      allowNull: true
    },
    profile_image_path: {
      type: Sequelize.STRING,
      allowNull: true
    },    
    is_active: {
      type: Sequelize.BOOLEAN,
      allowNull: true
    },     
    is_deleted: {
      type: Sequelize.BOOLEAN,
      allowNull: true,
      defaultValue: 0
    }, 
    created_by: {
      type: Sequelize.STRING,
      allowNull: false
    },
    updated_by: {
      type: Sequelize.STRING,
      allowNull: true
    },  
    file_name: {
      type: Sequelize.STRING,
      allowNull: true
    },   
    email:{
      type: Sequelize.STRING,
      allowNull: true
    },
    contractor_type:{
      type: Sequelize.INTEGER,
      allowNull: true
    },
    year_of_experience :{
      type: Sequelize.INTEGER,
      allowNull: true
    }, 
 
    contractor_description:{
      type: Sequelize.STRING,
      allowNull: true
    },
    KYC_details_filepath:{
      type: Sequelize.STRING,
      allowNull: true
    },
    GST_certificate_upload_path:{
      type: Sequelize.STRING,
      allowNull: true
    },
    PANID:{
      type: Sequelize.STRING,
      allowNull: true
    }, 
    AgreementDate:{
      type: Sequelize.DATE,
      allowNull: true
    },
    GST_certificate_upload_filename:{
      type: Sequelize.STRING,
      allowNull: true
    },
    KYC_details_filename:{
      type: Sequelize.STRING,
      allowNull: true
    },
    contractor_aadhar_filename:{
      type: Sequelize.STRING,
      allowNull: true
    },
    contractor_aadhar_filepath:{
      type: Sequelize.STRING,
      allowNull: true
    },
    contractor_gst_filename:{
      type: Sequelize.STRING,
      allowNull: true
    },
    contractor_gst_filepath:{
      type: Sequelize.STRING,
      allowNull: true
    },
    company_name:{
      type: Sequelize.STRING,
      allowNull: true
    },
    contractor_status:{
      type: Sequelize.INTEGER,
      allowNull: true
    },
  },
  {
    sequelize,
    tableName: "user_details"
  }
);
