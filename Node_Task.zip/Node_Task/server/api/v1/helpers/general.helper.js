const settings = require("../config/app.config");

let bcrypt = require("bcryptjs");
let jwt = require("jsonwebtoken");


let response;

class GeneralHelper {
 
  comparePassword(userpass,password) {
    return bcrypt.compareSync(password,userpass);
    
  }

  encryptPassword(password) {    
    return bcrypt.hashSync(password);
  }
 
  tokenGenerate(data, expire) {
    return jwt.sign(data, settings.config.JWT_SECRET, {
      expiresIn: expire
    });
  }

  tokenDecoded(token) {
    return jwt.verify(token, settings.config.JWT_SECRET, (err, decoded) => {
      if (err) {
        response = {
          status: 401
        };
        return response;
      } else {
        return decoded;
      }
    });
  }



  pagination(page, page_size) {
    let pagination = {
      offset:
        parseInt((page ? page : 1) - 1) * parseInt(page_size ? page_size : 10),
      limit: parseInt(page_size ? page_size : 10)
    };
    return pagination;
  }
 

  async getObjectFromS3(key_name) {
    aws.config.update({
      accessKeyId: settings.config.Aws_Accesskey_id,
      secretAccessKey: settings.config.Aws_Secret_Access_key,
      region: settings.config.Aws_Region,
      s3BucketEndpoint: true,
      endpoint: "http://" + settings.config.Aws_Bucket + ".s3.amazonaws.com"
    });
    let bucket = new aws.S3({ params: { Bucket: settings.config.Aws_Bucket } });
    return new Promise(function (resolve, reject) {
      bucket.getObject({ Key: key_name }, function (err, file) {
        if (err) {
          reject(err);
        }
        else {
          //let result = mimeType + encode(file.Body);
          resolve(file)
        }
      });
    });
  }
  async getS3SignedURL(key_name) {
    aws.config.update({
      accessKeyId: settings.config.Aws_Accesskey_id,
      secretAccessKey: settings.config.Aws_Secret_Access_key,
      region: settings.config.Aws_Region,
      //s3BucketEndpoint: true,
      // endpoint: "http://" + settings.config.Aws_Bucket + ".s3.amazonaws.com"
    });
    const s3 = new aws.S3()
    const myBucket = settings.config.Aws_Bucket;
    const myKey = key_name;
    const signedUrlExpireSeconds = 60;

    let url = s3.getSignedUrl('getObject', {
      Bucket: myBucket,
      Key: myKey,
      Expires: signedUrlExpireSeconds,
    });
    return url;
  }

}
export default new GeneralHelper();
