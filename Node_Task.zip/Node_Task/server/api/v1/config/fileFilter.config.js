/* 
add url that needs to be used for file upload
Please follow the below format for registering URL's
.post('/upload', fileUploadMiddleware.array('image',6), softwareController.bulkUploadSoftware);
1. here image should be parameter name,
2. 6 means no of files uploading
3. fileUploadMiddleware - this is a object name of fileupload.js

filter = [
  ["/api/v1/file/uploadfiles", "document|pdf", "5"]
  ["/api/v1/file/uploadfiles", "image", "5"]
];
every url should register as Array
1. first parameter is url accessing file upload
2. second parameter is file extensions allowed
3. third parameter is file size to be allowed (if file size is 150 then it is 150kb)
4. Fourth parameter is used to save the file in specified directory (destination folder)
*/
let filter = [

];

/*
key of this object will be used as refernce in above filter register
add new key and extension into the values if needed a new extension type in validation
*/
let filterExt = {
  image: "jpeg,png,jpg",
  excel: "xls,xlsx",
  document: "doc,docx",
  pdf: "pdf,PDF"
};

export  let fileFilter = { filter, filterExt };
