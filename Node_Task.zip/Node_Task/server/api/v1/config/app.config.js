/*
Add all the configuration regarding the application as key value pair here
*/
export const config = {
  //---DEV---
  DB_NAME: "",
  DB_USER: "",
  DB_PASSWORD: "",
  DB_HOST: "",

  DIALECT: "mysql",

};
