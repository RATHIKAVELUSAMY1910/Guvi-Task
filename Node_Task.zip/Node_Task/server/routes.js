import userRouter from "./api/v1/controllers/user/userRouter";

import loginRouter from "./api/v1/controllers/login/loginRouter";
import MasterRouter from "./api/v1/controllers/master/masterRouter";



 export default function routes(app) {
   // version 1.0.0 Routes  
 app.use("/api/v1/user", userRouter);

 app.use("/api/v1/login", loginRouter);
 app.use("/api/v1/master", MasterRouter);

}
