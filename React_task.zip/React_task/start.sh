serve -l 8086 -s build
