import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Login from "./pages/login/Login";
import EditUser from "./components/edit-user/edit-user";

const App = () => {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/" component={Login}></Route>
          <Route
            exact
            path="/edit-user"
            component={EditUser}
          ></Route>
        </Switch>
      </Router>
    </div>
  );
};

export default App;
