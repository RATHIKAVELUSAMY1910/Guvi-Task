import React, {  useState, useEffect } from "react";
import "./login.css";

import Swal from "sweetalert2";
import Loading from 'react-fullscreen-loading';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import $ from "jquery";
import {
  Button,
} from "@material-ui/core";
import { postAPI, getAPI } from "../../api/apiClient";
import storage from "../../helpers/storageHelper";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";

export default function Login() {
  const [state, setState] = useState({
    IsLoading: false,
    IsForgotPassword: false
  });
  const eye = <FontAwesomeIcon icon={faEye} />;
  const [mobileNumber, setMobileNumber] = useState("");

  const [passwordShown, setPasswordShown] = useState(false);
  const [PIN, setPIN] = useState("");
  const [snackMsg, setSnackMsg] = useState({
    msg: null, severity: "error"
  });
  const isNumber = /^[0-9-\b]+$/;
  useEffect(async () => {
    resetSessions();
  }, []);

  const handleCloseAlert = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setSnackMsg({ ...snackMsg, msg: null });
  };

  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };

  const resetSessions = async () => {
    storage.setValue("token", "");
    storage.setValue("user_id", "");
    storage.setValue("user_code", "");
    storage.setValue("first_name", "");
    storage.setValue("last_name", "");
    storage.setValue("profile_image_path", "");
    storage.setValue("role_id", "");
    storage.setValue("role_name", "");
    storage.setValue("forgotPassword", "")
    storage.setValue("mobile_number", "")
  }

  const login = async (evt) => {
    if (mobileNumber == "") {
      setSnackMsg({ msg: "Enter mobile number!", severity: "warning" });
    }
    else if (!isNumber.test(mobileNumber) || mobileNumber.length < 10) {
      setSnackMsg({ msg: "Enter valid mobile number!", severity: "warning" });
    }
    else if (PIN == "") {
      setSnackMsg({ msg: "Enter PIN!", severity: "warning" });
    }
    else if (!isNumber.test(PIN)) {
      setSnackMsg({ msg: "Enter valid password!", severity: "warning" });
    }
    else {
      setState({ ...state, IsLoading: true });
      let requestData = {
        url: `login/login-user`,
        payload: {
          mobile_number: mobileNumber,
          pin_number: PIN,
          is_from_mobile: "0"
        },
      };
      const response = await postAPI(requestData, "", "v1");
      if (response.status == 200) {
        setState({ ...state, IsLoading: false });
      
      
         
          storage.setValue("user_id", response.content.login_details.user_id);
          storage.setValue("user_code", response.content.login_details.user_code);
          storage.setValue("first_name", response.content.login_details.first_name);
          storage.setValue("last_name", response.content.login_details.last_name);
          storage.setValue("mobile_number", response.content.login_details.mobile_number);
       
      
          window.location = "/edit-user";
        
      
      }
      else if (response.status == 405 || response.status == 402 || response.status == 403) {
        setState({ ...state, IsLoading: false });
        setSnackMsg({ msg: response.content, severity: "error" });
      }
      else {
        setState({ ...state, IsLoading: false });
        Swal.fire("", "Something went wrong!", "error");
      }
    }
  }

  const handleLoginEnter = async (evt) => {
    if (evt.key === 'Enter') {
      login();
    }
  }



  const handleSignUp = async (e) => {
    window.location = "/edit-user";
  }

 

  return (
    <div class="login-body">
      <Loading
        loading={state.IsLoading}
        background="rgba(0,0,0,0.6)"
        loaderColor="#2d88ff"
      />
      <Snackbar
        open={snackMsg.msg}
        autoHideDuration={2000}
        onClose={handleCloseAlert}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <MuiAlert elevation={6} variant="filled" onClose={handleCloseAlert} severity={snackMsg.severity} > {snackMsg.msg}</MuiAlert>
      </Snackbar>
      <div class="row">
        <div class="position-relative col-xl-4 login-bg d-none d-md-inline-block">
          <div class="logo-position">
           
          </div>
        </div>
     
            <div class="col-xl-8 align-items-center justify-content-center login-wrapper login-bg1">
              <div class="polygon-bg"></div>
              <div class="container login-form">
               
                <p> Login</p>
                <form class="text-center mt-5 form-content">
                  {/* -------- */}
                  <div class="input-group login-input-group mb-3 ">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1">
                        <i class="fa fa-user f-18 mr-1"></i>
                      </span>
                    </div>
                    <input
                      type="text"
                      id="txtMobileNumber"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      onKeyUp={handleLoginEnter}
                      class="form-control field-control"
                      maxlength="15"
                      placeholder="Mobile Number"
                      aria-label="Mobile Number"
                      aria-describedby="basic-addon1"
                    />
                  </div>
                  <div class="input-group login-input-group ">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1">
                        <i class="fa fa-key f-18"></i>
                      </span>
                    </div>
                    <input
                      type={passwordShown ? "text" : "password"}
                      id="txtPassword"
                      value={PIN}
                      onChange={(e) => setPIN(e.target.value)}
                      onKeyUp={handleLoginEnter}
                      class="form-control field-control"
                      //className="form-control"
                      placeholder="Password"
                      maxlength="4"
                    //aria-label="Password"
                    //aria-describedby="basic-addon1"
                    />
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1">
                      <i onClick={togglePasswordVisiblity} className="">
                      {eye}
                    </i>
                      </span>
                    </div>
                    
                  </div>
                  {/* --------- */}

                  <Button
                    variant="contained"
                    className="btn btn-secondary w-100 mt-4 mb-5"
                    onClick={login}
                  >
                    Submit
                  </Button>
                  
                  <a onClick={handleSignUp} name="FP" class="forgot-link w-100 mt-5">
                    {" "}
              New User?{" "}
                  </a>
                </form>
              </div>
            </div>
         
      </div>
    </div >
  );
};
//export default Login;
