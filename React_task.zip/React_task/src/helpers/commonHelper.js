import moment from "moment";
export default class CommonHelper {
  checkPropertyExist (property, param) {
    if (param.hasOwnProperty (property)) {
      if (param[property] !== undefined) {
        return true;
      }
    }
    return false;
  }
  async apiSweetAlert (messageFormat) {
    let messages = '';
    for (var message in messageFormat) {
      messages = messages + '<p>' + messageFormat[message] + '</p>';
    }
    return messages;
  }

  async getUTCStartEndDate(start_date, end_date)
  {
    return await new Promise((resolve,reject)=>{
      let s = moment(`${start_date} 00:00:00`).utc().format("YYYY-MM-DD HH:mm:ss");
      let e = moment(`${end_date} 23:59:59`).utc().format("YYYY-MM-DD HH:mm:ss");
      resolve([s,e]);
    });
  }
}
