import React from 'react'
import { makeStyles, Button } from "@material-ui/core";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import DownloadIcon from '../assets/Icons/excel.svg';

export const ExportCSV = ({ csvData, fileName, fnExportdata, text, arrSheetlist }) => {
  const classes = useStyles();

  const min = 1;
  const max = 100;
  const random = min + (Math.random() * (max - min));

  //let newDate = new Date();
  // date = newDate.getDate();

  const file_Name = fileName;
  const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  const fileExtension = '.xlsx';

  const exportToCSV = (csvData, file_Name) => {
    if (csvData != "") {
      if (csvData.length > 0 && !arrSheetlist) {
        const ws = XLSX.utils.json_to_sheet(csvData,);
        // ws.A1.Date = "Name";
        //ws[Date].v = ws[Date].v.toUpperCase();
        const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };
        //XLSX.utils.book_append_sheet(wb, ws);
        //XLSX.utils.sheet_add_json(ws, csvData, {skipHeader: true,origin: "A2"});
        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelBuffer], { type: fileType });
        FileSaver.saveAs(data, file_Name + fileExtension);
      }
      else if (csvData.length > 0) {
        let dicSheets = {};
        let arrSheetNames = [];
        for (let i = 0; i < csvData.length; ++i) {
          dicSheets[(arrSheetlist && arrSheetlist[i]) ? arrSheetlist[i] : 'Sheet_' + i] = XLSX.utils.json_to_sheet(csvData[i],);
          arrSheetNames.push((arrSheetlist && arrSheetlist[i]) ? arrSheetlist[i] : 'Sheet_' + i);
        }
        const wb = { Sheets: dicSheets, SheetNames: arrSheetNames };
        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelBuffer], { type: fileType });
        FileSaver.saveAs(data, file_Name + fileExtension);
      }
    }
    else {
      alert('No Records found');
    }
  };

  return (
    <Button className={classes.uploadbutton}
      onClick={(e) => {
        if (csvData) {
          exportToCSV(csvData, file_Name)
        } else if (fnExportdata) {
          fnExportdata().then(expdata => {
            exportToCSV(expdata, file_Name, arrSheetlist)
          });
        }
      }}>
      <img src={DownloadIcon} style={{ marginRight: "7px" }} />{text ? text : 'Download Excel'}
    </Button>
  );
};
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },

  uploadbutton: {
    height: 40,
    minWidth: "175px",
    background:
      "transparent linear-gradient(180deg, #2D88FC 0%, #1962BF 100%) 0% 0% no-repeat padding-box",
    fontSize: 15,
    color: "white",
    marginTop: 14,

    position: "relative",
    [theme.breakpoints.down("xs")]: {
      minWidth: "146px",
      fontSize: "13px",
    },
  },
}));
