import React from "react";
import { useState, useEffect } from "react";
/*plugin*/
import { useForm } from "react-hook-form";
/*css*/
import "./edit-user.css";

/*pages*/

import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faKey } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUpload } from "@fortawesome/free-solid-svg-icons";
import UpdateImg from "../../assets/img/images/add-user.svg";
import { useDropzone } from "react-dropzone";
import Swal from "sweetalert2";
import Loading from "react-fullscreen-loading";
import moment from "moment";
import Snackbar from "@material-ui/core/Snackbar";
import { postAPI, getAPI, formDataGetUrl } from "../../api/apiClient";
import storage from "../../helpers/storageHelper";
import MuiAlert from "@material-ui/lab/Alert";
import {
  Dialog,
  Typography,
  makeStyles,
  Container,
  Menu,
  Box,
  TextField,
  InputAdornment,
  IconButton,
  Button,
  MenuItem,
  Link,
  Grid,
  Card,
  CardMedia,
  CardContent,
} from "@material-ui/core";

const cloud = <FontAwesomeIcon icon={faUpload} />;
const eye = <FontAwesomeIcon icon={faEye} />;
const key = <FontAwesomeIcon icon={faKey} />;

const EditUser = () => {
  const [showSidebar, setShowSidebar] = useState(false);
  const initialFormState = {
    user_code: "",
    first_name: "",
    last_name: "",
    mobile_number: "",
    dob: "",
    address: "",
    cityName: "",
    stateName: "",
    pin_code: "",
    gender: "",
    profile_image_path: "",
    is_active: "",
    updatedAt: "",
  };
  const [UserProfileData, setUserProfileData] = useState(initialFormState);
  const sidebarOpenHandler = () => {
    setShowSidebar((value) => !showSidebar);
  };
  const [passwordShown, setPasswordShown] = useState(false);
  //   const eye = <FontAwesomeIcon icon={faEye} />;
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };
  useEffect(() => {
  
    LoadState();
    if(storage.getValue("user_id")!='')
    {
    GetProfile();
    }
  }, []);
  const [yourImage, setImage] = useState([]);
  const [preview, setPreview] = useState();
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [base64Profile, setbase64Profile] = useState("");
  const [state, setState] = useState({
    IsLoading: false,
  });
  

  const [snackMsg, setSnackMsg] = useState({
    msg: null,
    severity: "error",
  });
  const handleCloseAlert = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setSnackMsg({ ...snackMsg, msg: null });
  };
  const handleChangestate = async (event) => {
    let stateid = event.target.value;
    LoadCity(stateid);
    const { name, value } = event.target;
    setUserProfileData({ ...UserProfileData, [name]: value, cityName: "" });
  };
  const handleChange = async (event) => {
    const { name, value } = event.target;

    setUserProfileData({ ...UserProfileData, [name]: value });
  };
  const onHandleChangeNumeric = async (event) => {
    const { name, value } = event.target;
    if (!/^[0-9]{1,100}$/.test(value) && value != "") {
      return;
    }
    setUserProfileData({ ...UserProfileData, [name]: value });
  };
  const handleDOBChange = async (event) => {
    var value = event.target.value;
    var DOB = moment(value);
    var now = moment();
    var Age = now.diff(DOB, "years");

    if (Age < 18) {
      setSnackMsg({ msg: "Child labour not allowed!", severity: "error" });

      var name = event.target.name;
      setUserProfileData({ ...UserProfileData, [name]: "" });
    } else {
      var name = event.target.name;
      setUserProfileData({ ...UserProfileData, [name]: value });
    }
  };
  const handleGenderChange = async (event) => {
    let value;
    if (event.target.name == "male_radio") {
      value = 1;
    } else value = 2;
    setUserProfileData({ ...UserProfileData, gender: value });
  };

  const LoadState = async () => {
    let requestData = {
      url: "master/get-state",
    };
    let response = await getAPI(requestData, "", "v1");
    response = JSON.parse(JSON.stringify(response));
    if (response.content) {
      setStateList(response.content);
    } else {
      return false;
    }
  };
  const LoadCity = async (stateid) => {
    let requestData = {
      url: "master/city/list?state_id=" + stateid,
    };
    let response = await getAPI(requestData, "", "v1");
    response = JSON.parse(JSON.stringify(response));
    if (response.content) {
      setCityList(response.content);
    } else {
      setCityList([]);
    }
  };
 
  const GetProfile = async () => {
    setState({ ...state, IsLoading: true });

    let requestData = {
      url:
        "user/profile-list?id=" +
        storage.getValue("user_id") ,
    };
    const response = await getAPI(requestData, "", "v1");
    if (response.status == 200) {
      console.log(response.content)
      setUserProfileData({
        user_code: response.content.user_code,
        first_name: response.content.first_name,
        last_name: response.content.last_name,
        mobile_number: response.content.mobile_number,
        dob: response.content.dob,
        address: response.content.address,
        cityName: response.content.city_id,
        stateName: response.content.state_id,
        pin_code: response.content.pin_code,
        gender: response.content.gender,
        profile_image_path: response.content.profile_image_path,
        is_active: response.content.is_active,
        updatedAt: moment(response.content.updatedAt).format(
          "YYYY/MM/DD hh:mm:ss A"
        ),
      });
      LoadCity(response.content.state);
    
      setState({
        ...state,
        IsLoading: false,
      });
    } else {
      setState({
        ...state,
        IsLoading: false,
      });

      setSnackMsg({ msg: "Users data not available!", severity: "error" });
    }
  };
  const Back = async () => {
    window.location = "/";
  }
  const UpdateUser = async () => {
    setState({ ...state, IsLoading: true });

    var Cur_datetime = moment().format("YYYY-MM-DD");
    let textvalid = /^[a-zA-Z\s]+$/;
    if (UserProfileData.dob != "") {
      var DOB = moment(UserProfileData.dob);
      var now = moment();
      var Age = now.diff(DOB, "years");
    }
    if (UserProfileData.first_name == "") {
      setSnackMsg({ msg: "Enter First Name", severity: "error" });
    } else if (
      UserProfileData.first_name != "" &&
      !textvalid.test(UserProfileData.first_name)
    ) {
      setSnackMsg({ msg: "Enter Valid First Name", severity: "error" });
    } else if (UserProfileData.last_name == "") {
      setSnackMsg({ msg: "Enter Last Name", severity: "error" });
    } else if (
      UserProfileData.last_name != "" &&
      !textvalid.test(UserProfileData.last_name)
    ) {
      setSnackMsg({ msg: "Enter Valid First Name", severity: "error" });
    } else if (UserProfileData.dob == "") {
      setSnackMsg({ msg: "Enter Date of Birth", severity: "error" });
    } else if (
      (new Date(UserProfileData.dob).getFullYear() + "").length != 4 ||
      new Date(UserProfileData.dob).getFullYear() + "" >
        new Date().getFullYear() ||
      new Date(UserProfileData.dob).getFullYear() + "" < 1950
    ) {
      setSnackMsg({ msg: "Select valid date of birth", severity: "error" });
    } else if (Cur_datetime <= UserProfileData.dob) {
      setSnackMsg({
        msg: "Date of birth should be less then current Date",
        severity: "error",
      });
    } else if (Age < 18) {
      setSnackMsg({ msg: "Child labour not allowed", severity: "error" });
    } else if (UserProfileData.gender == "") {
      setSnackMsg({ msg: "Choose Gender", severity: "error" });
    } else if (UserProfileData.address == "") {
      setSnackMsg({ msg: "Enter address", severity: "error" });
    } else if (UserProfileData.pin_code == "") {
      setSnackMsg({ msg: "Enter Pincode", severity: "error" });
    } else if (
      isNaN(UserProfileData.pin_code) ||
      UserProfileData.pin_code.length < 6
    ) {
      setSnackMsg({ msg: "Enter valid pincode", severity: "error" });
    } else if (
      UserProfileData.stateName == "" ||
      UserProfileData.stateName == "Select"
    ) {
      setSnackMsg({ msg: "Choose State", severity: "error" });
    } else if (
      UserProfileData.cityName == "" ||
      UserProfileData.cityName == "Select"
    ) {
      setSnackMsg({ msg: "Choose City", severity: "error" });
    } else {
      let requestData = {
        url: `user/`,
        payload: {
          first_name: UserProfileData.first_name,
          last_name: UserProfileData.last_name,
          mobile_number: UserProfileData.pin_code,
          state: UserProfileData.stateName,
          city: UserProfileData.cityName,
          pin_code: UserProfileData.pin_code,
          address: UserProfileData.address,
          dob: UserProfileData.dob,
          gender: UserProfileData.gender,
          pin_number:'1111'

        },
      };
    
      const response = await postAPI(requestData, "", "v1");
      if (response.status == 200) {
        setState({
          ...state,
          IsLoading: false,
        });
        storage.setValue("first_name", UserProfileData.first_name);
        storage.setValue("last_name", UserProfileData.last_name);
        window.location = "/";
      } else {
        setState({
          ...state,
          IsLoading: false,
        });

        setSnackMsg({ msg: "Users data not available!", severity: "error" });
      }
    }
    setState({
      ...state,
      IsLoading: false,
    });
  };
  return (
    <div>
   
      <Loading
        loading={state.IsLoading}
        background="rgba(0,0,0,0.6)"
        loaderColor="#2d88ff"
      />
      <Snackbar
        open={snackMsg.msg}
        autoHideDuration={2000}
        onClose={handleCloseAlert}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <MuiAlert
          elevation={6}
          variant="filled"
          onClose={handleCloseAlert}
          severity={snackMsg.severity}
        >
          {" "}
          {snackMsg.msg}
        </MuiAlert>
      </Snackbar>
      <div className="main-content bg-white" id="panel">
      

        <div className="pl-2 pr-2  pt-4">
          <div className="container-fluid user-header">
            <h1> Profile</h1>
            <div className="row pb-3 pt-4">
              <div className="col-lg-8 col-md-8 col-sm-12">
                <form>
                  {/* Update User */}
                  <div>
                    <div className="card update-user-card mt-3">
                      <div className="card-body pt-2">
                    
                        <form>
                          <div class="row ">
                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>First Name</label>
                              </div>
                              <input
                                type="text"
                                className="form-control"
                                id="text"
                                aria-describedby="name"
                                placeholder="First Name"
                                name="first_name"
                                value={UserProfileData.first_name}
                                onChange={(e) => {
                                  let value = e.target.value;

                                  value = value.replace(/[^A-Za-z]/gi, "");
                                  setUserProfileData({
                                    ...UserProfileData,
                                    first_name: value,
                                  });
                                }}
                                maxLength="30"
                              />
                            </div>
                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>Last Name</label>
                              </div>
                              <input
                                type="text"
                                className="form-control"
                                id="text"
                                aria-describedby="name"
                                placeholder="Last Name"
                                name="last_name"
                                value={UserProfileData.last_name}
                                onChange={(e) => {
                                  let value = e.target.value;

                                  value = value.replace(/[^A-Za-z]/gi, "");
                                  setUserProfileData({
                                    ...UserProfileData,
                                    last_name: value,
                                  });
                                }}
                                maxLength="30"
                              />
                            </div>
                          </div>
                          <div class="row ">
                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>Date of birth</label>
                              </div>
                              <input
                                type="date"
                                className="form-control"
                                id="date"
                                placeholder="Date of birth"
                                name="dob"
                                min="1950-01-01"
                                max={
                                  new Date().getFullYear() -
                                  17 +
                                  "-" +
                                  (new Date().getMonth().toString().length == 1
                                    ? "0" + new Date().getMonth().toString()
                                    : new Date().getMonth()) +
                                  "-" +
                                  ((new Date().getDate() - 1).toString()
                                    .length == 1
                                    ? "0" +
                                      (new Date().getDate() - 1).toString()
                                    : new Date().getDate() - 1)
                                }
                                value={UserProfileData.dob}
                                onChange={handleDOBChange.bind(this)}
                                onKeyDown={(e) => e.preventDefault()}
                              />
                            </div>

                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>Gender</label>
                              </div>
                              <div className="form-group custom-radio-button d-flex form-check-inline form-check mb-0">
                                <div class="col-md-6 radio">
                                  <input
                                    id="male"
                                    name="male_radio"
                                    type="radio"
                                    className="form-check-input"
                                    checked={
                                      UserProfileData.gender == 1 ? true : false
                                    }
                                    onChange={handleGenderChange}
                                  />
                                  <label
                                    for="male"
                                    class="radio-label d-inline-flex align-items-center"
                                  >
                                    Male
                                  </label>
                                </div>

                                <div class="radio">
                                  <input
                                    id="female"
                                    name="female_radio"
                                    type="radio"
                                    checked={
                                      UserProfileData.gender != 1 ? true : false
                                    }
                                    onChange={handleGenderChange}
                                  />
                                  <label
                                    for="female"
                                    class="radio-label d-inline-flex align-items-center"
                                  >
                                    Female
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="row ">
                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>Address</label>
                              </div>
                              <textarea
                                name="plot Address"
                                form="usrform"
                                className="form-control"
                                placeholder=" Plot Address"
                                name="address"
                                onChange={handleChange.bind(this)}
                                maxLength="500"
                                value={UserProfileData.address}
                              ></textarea>
                            </div>
                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>Mobile Number</label>
                              </div>
                              <input
                                type="text"
                                className="form-control"
                                id="pin_code"
                                aria-describedby="name"
                                placeholder="Pin Code"
                                name="pin_code"
                                maxLength="10"
                                value={UserProfileData.pin_code}
                                onChange={onHandleChangeNumeric.bind(this)}
                              />
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>State</label>
                              </div>
                              <select
                                className="custom-select"
                                name="stateName"
                                value={UserProfileData.stateName}
                                onChange={handleChangestate.bind(this)}
                              >
                                <option selected>Select</option>
                                {stateList.map((State) => (
                                  <option key={State.name} value={State.id}>
                                    {State.name}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div class="col-sm-12 col-md-6 form-group">
                              <div className="">
                                <label>City</label>
                              </div>
                              <select
                                className="custom-select"
                                name="cityName"
                                value={UserProfileData.cityName}
                                onChange={handleChange.bind(this)}
                              >
                                <option selected>Select</option>
                                {cityList.map((city) => (
                                  <option key={city.name} value={city.id}>
                                    {city.name}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <div class="row form-group text-center">
                            <div class="col-sm-12 col-md-6"></div>

                    
                          {storage.getValue("user_id")==''?  <Button
                              variant="contained"
                              className="btn btn-primary update-user-btn  mt-2"
                              onClick={UpdateUser}
                            >
                              Sign Up
                            </Button>:<Button
                              variant="contained"
                              className="btn btn-primary update-user-btn  mt-2"
                              onClick={Back}
                            >
                             Back
                            </Button>}
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  {/* Update User */}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
     
    </div>
  );
};

export default EditUser;
