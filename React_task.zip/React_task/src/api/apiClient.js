import CommonHelper from '../helpers/commonHelper';
import Swal from 'sweetalert2';

//Dev
const hostURL = 'http://localhost:8085';
//QA
//const hostURL = 'https://172.16.6.5:8093';
//UAT
//const hostURL = 'https://sonahomesuatapi.vee-services.com';

const pathURL = '/api/';


const helper = new CommonHelper();
async function getBaseURl(param, version) {
  const checkHostname = await helper.checkPropertyExist('host', param);
  let baseURL;
  if (checkHostname) {
    baseURL = param.host;
  } else {
    baseURL = hostURL + pathURL + version + '/';
  }

  return baseURL;
}

export async function formDataGetUrl (version, route) {
  let url = hostURL + pathURL + version + '/' + route;
  return url;
}

 async function callAPI (url, param, thisProps, callBackfunction) {
  try {
    const response = await fetch (url, param);
    
    if (
      response.status !== 200 &&
      response.status !== 201 &&
      response.status !== 402 &&
      response.status !== 403 &&
      response.status !== 405 &&
      response.status !== 422 &&
      response.status !== 400 &&
      response.status !== 406	
    ) {
      return await handleError (response, thisProps, callBackfunction);
    } else {
      let responseJson = await response.json ();
      if (typeof responseJson == 'string') {
        responseJson = JSON.parse (responseJson);
      }
      return responseJson;
    }
  } catch (error) {
    return await handleError (error, thisProps, callBackfunction);
  }
}

export async function getAPI (param, thisProps, version, callBackfunction) {
  const request = await getParam ('GET', param);
  const baseURL = await getBaseURl (param, version);
  const response = await callAPI (
    baseURL + param.url,
    request,
    thisProps,
    callBackfunction
  );
  return response;
}

export async function postAPI (param, thisProps, version, callBackfunction) {
  const request = await getParam ('POST', param);
  const baseURL = await getBaseURl (param, version);
  const response = await callAPI (
    baseURL + param.url,
    request,
    thisProps,
    callBackfunction
  );
  return response;
}

export async function deleteAPI (param, thisProps, version) {
  const request = await getParam ('DELETE', param);
  const baseURL = hostURL + pathURL + version + '/';
  const response = await callAPI (baseURL + param.url, request, thisProps);
  return response;
}

async function getParam (method, param) {
  let request = {};
  request['method'] = method;

  const checkAuthKey = await helper.checkPropertyExist ('token', param);

  if (checkAuthKey) {
    request['headers'] = {
      Authorization: 'Bearer ' + param.token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
  } else {
    request['headers'] = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
  }

  const checkPayload = await helper.checkPropertyExist ('payload', param);

  if (checkPayload) {
    request['body'] = JSON.stringify (param.payload);
  }

  return request;
}

async function handleError (error, thisProps, callBackfunction) {
  switch (error.status) {
    case 401: {
      await helper.logOut ();
      window.location.replace ('/login');
      /* falls through */
      break;
    }
    case 403: {
      return showErrorPage (error, thisProps, '/login');
    }
    case 404: {
      return showErrorPage (error, thisProps, '/404');
    }
    case 500: {
      Swal.fire (
        'Oops!!',
        'Something went Wrong. Please Try again Later.',
        'error'
      );
      return false;
    }
    default: {
      Swal.fire (
        'Oops!!',
        'Something went Wrong. Please Try again Later.',
        'error'
      );
      let manualError = {
        content: {message: 'Something Went Wrong'},
      };
      return showErrorMessage (manualError, thisProps, callBackfunction);
    }
  }
}

function showErrorPage (error, thisProps, page) {
  return thisProps.history.push (page);
}

function showErrorMessage (error, thisProps, callBackfunction = null) {
  let message = error.content ? error.content : {message: error.message};
  if (callBackfunction) {
    callBackfunction (message);
  }
  return error;
}

export async function handleApiErrors(respObj, history) {
 
  switch (respObj.status) {
    case 401: {
 
      Swal.fire({
        text: "Session Expired. Please Re-Login.",
        icon: 'error'
      }, function () {
        history.push("/login");
      }
      );
      break;
    }
    case 403: {
      Swal.fire({
        title: 'Error',
        text: respObj.message,
        icon: 'error'
      }
      );
      history.push("/login");
      break;
    }
    case 404: {
      Swal.fire({
        title: 'Error',
        text: respObj.message,
        icon: 'error'
      }
      );
      break;
    }
    case 500: {
      Swal.fire({
        text: 'Something went Wrong. Please Try again Later.',
        icon: 'error'
      }
      );
      break;

    }
    default: {
      Swal.fire({
        title: 'Error',
        text: respObj.message,
        icon: 'error'
      }
      );
      break;
    }
  }
}

export const serverconnect = hostURL.toString();
export const getImage = hostURL.toString();
